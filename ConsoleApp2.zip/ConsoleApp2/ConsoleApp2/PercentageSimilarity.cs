﻿using System;
namespace ConsoleApp2
{
    public static class SimilarityExtensions
    {
        /// <summary>
        /// Returns the number of steps required to transform the source string
        /// into the target string.
        /// </summary>
        public static int ComputeLevenshteinDistance(this string name1, string name2)
        {
            if (string.IsNullOrEmpty(name1))
                return string.IsNullOrEmpty(name2) ? 0 : name2.Length;

            if (string.IsNullOrEmpty(name2))
                return string.IsNullOrEmpty(name1) ? 0 : name1.Length;

            int sourceLength = name1.Length;
            int targetLength = name2.Length;

            int[,] distance = new int[sourceLength + 1, targetLength + 1];

            // Step 1
            for (int i = 0; i <= sourceLength; distance[i, 0] = i++) ;
            for (int j = 0; j <= targetLength; distance[0, j] = j++) ;

            for (int i = 1; i <= sourceLength; i++)
            {
                for (int j = 1; j <= targetLength; j++)
                {
                    // Step 2
                    int cost = (name2[j - 1] == name1[i - 1]) ? 0 : 1;

                    // Step 3
                    distance[i, j] = Math.Min(
                                        Math.Min(distance[i - 1, j] + 1, distance[i, j - 1] + 1),
                                        distance[i - 1, j - 1] + cost);
                }
            }

            return distance[sourceLength, targetLength];
        }

        /// <summary>
        /// Calculate percentage similarity of two strings
        /// <param name="source">Source String to Compare with</param>
        /// <param name="target">Targeted String to Compare</param>
        /// <returns>Return Similarity between two strings from 0 to 1.0</returns>
        /// </summary>
        public static double CalculateSimilarity(this string name1, string name2)
        {
            if (string.IsNullOrEmpty(name1))
                return string.IsNullOrEmpty(name2) ? 1 : 0;

            if (string.IsNullOrEmpty(name2))
                return string.IsNullOrEmpty(name1) ? 1 : 0;

            double stepsToSame = ComputeLevenshteinDistance(name1, name2);
            return (1.0 - (stepsToSame / (double)Math.Max(name1.Length, name2.Length)));
        }
    }
}
