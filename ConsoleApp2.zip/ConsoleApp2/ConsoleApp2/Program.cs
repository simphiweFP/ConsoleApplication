﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;

using System.Data.SqlTypes;
using System.IO;
using System.Linq;

namespace ConsoleApp2
{
    class Program
    {
        static void Main(string[] args)
        {

            SqlConnection sfp = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=" + " C:\\Users\\user\\source\\repos\\ConsoleApp2\\ConsoleApp2\\Database2.mdf " + ";Integrated Security=True");
            sfp.Open();
            string name1, name2;
            double percentage = 0;
           

            Console.Write("Please enter source string: ");
            name1 = Console.ReadLine();
            Console.Write("Please enter target string: ");
            name2 = Console.ReadLine();
            if ((name1.ToLower().CalculateSimilarity(name2.ToLower()) * 100) >= 80)
            {
                //"Jack matches Jill 82%, good match"
                //System.Text.StringBuilder sb = new
                //System.Text.StringBuilder(" {0}% " + name1.ToLower().CalculateSimilarity(name2.ToLower()) * 100);
                //sb.Append(name1).Append(" matches ").Append(name2).Append(" {0}% " + name1.ToLower().CalculateSimilarity(name2.ToLower()) * 100).Append(" Good match ");
                //Console.WriteLine(sb);
                Console.WriteLine(name1 + " matches " + name2 + " {0}% ," + " Good match ", name1.ToLower().CalculateSimilarity(name2.ToLower()) * 100);
                percentage = (name1.ToLower().CalculateSimilarity(name2.ToLower()) * 100);
                //Console.WriteLine("Percentage " + percentage);


                SqlCommand cmd = new SqlCommand("insert into tbl_ApplicationFirstNames values('" + name1 + "','" + name2 + "','" + percentage + "')", sfp);
                int i = cmd.ExecuteNonQuery();
                if (i > 0)
                {
                    Console.WriteLine("Insertion successful");
                }
                sfp.Close();

                ReadCSVFile();
                Console.ReadLine();

                



            }
            else
            {
                Console.WriteLine(name1 + " Did Not match  " + name2 + " {0}% ," + "  Try Other match ", name1.ToLower().CalculateSimilarity(name2.ToLower()) * 100);
                ReadCSVFile();
                Console.ReadLine();
               
            }



           
            
            static void ReadCSVFile()
            {
                var lines = File.ReadAllLines("Details.csv");
                var list = new List<Gender>();
                foreach (var line in lines)
                {
                    var values = line.Split(',');
                    var gender = new Gender() { name = values[0], gender = values[1] };
                    list.Add(gender);
                    
                }
                //list.ForEach(x => Console.WriteLine($"{x.name}\t{x.gender}"));
                var sortedGender = from x in list
                                   orderby x.gender
                                   select x;

                 foreach (var gender in sortedGender)
                {
                    Console.WriteLine(gender.name + gender.gender);
                }
              


              

            }
        }

          
        public class Gender
        {
            public string name { get; set; }
            public string gender { get; set; }
        }
        
    }
}
 


